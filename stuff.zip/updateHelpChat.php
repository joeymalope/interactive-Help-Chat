<?php
require "config.php";
function foo(){
$conn=$_SESSION["conn"];   
$sql="SELECT * FROM pendingqueriestbl p inner join replytbl r on p.staff_id = r.staff_id where p.staff_id = r.staff_id AND p.staff_id=1  Order by qid desc";
    if($result = mysqli_query($conn,$sql)){ 
        if (mysqli_num_rows($result)> 0) {
            echo " <ul class='list-group'>";
            while($row = mysqli_fetch_assoc($result)) {
                    echo "<li class='list-group-item'>";
                    echo "<h2>".$row["qid"]."#</h2>";
                    echo "<span class=''>User:".$row["user"].
                        "</span> <br />"."</span><br />Query:".
                        $row["query"];
                    echo "<span>".$row["reply"]."</span></li>";
            }
            echo "</ul>";
        } 
    }
    echo "hello ".mysqli_error($result);
}

foo();
?>
