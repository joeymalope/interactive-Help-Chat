<!DOCTYPE html>
<html>	
<head>
	<meta name="author"  content="Pappi Malope">
	<title>
		
	</title>
	<meta charset="UTF-8" />
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/styles.css">
	<script src="bootstrap/js/jquery-2.1.3.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="helpChat.js">

	</script>
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-xs-12" id="header">
			</div>
		</div>	
		<div class="row" id="login">
			<div class="col-md-6 col-md-offset-3 col-xs-12">
                <form action="" id="myform" method="post">
                    <div class="form"> 
                        <div class="form-group">
                            <label>Name:
                                <input type="text" class="form-control" name="name" id="name" placeholder="Username" required/>
                            </label>    
                        </div>				
                        <div class="form-group">
                            <textarea name="query" resize="none" id="query" placeholder="Enter Help Query" required>Enter Help Query </textarea>
                        </div>	
                        <div class="form-group">  
                            <?php
                                require "config.php";
                                $sql="select * from helpdesktbl";
                                $result=mysqli_query($_SESSION["conn"],$sql); 
                               if(mysqli_num_rows($result) > 0) {
                                        while($row = mysqli_fetch_assoc($result)) {
                                           // echo "id: " . $row["staff_id"]."<br>";
                                            $staff_id=$row["staff_id"];
                                    echo "<label>";
                                    echo  "<span> ".$row['name']."</span>";
                                    echo "<input type='radio' name='staff' value=".$row['staff_id']." required/></label>";
                                }                                 
                            }
                            ?>    
                        </div>	    
                        <div class="form-group">
                            <button type="submit" name="submit" id="submitQ">
                                Send Query
                            </button>
                        </div>
                    </div>    
                </form> 
        		<div class="chatarea col-md-6 col-md-offset-3 col-xs-12">
                  
				</div>
			</div>
           <button type="submit" name="submit" id="submit">
               Send Query
             </button>
			<div class="col-md-6">

			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-xs-12" id="footer">	
		</div>
	</div>	
</div>
</body>
</html>