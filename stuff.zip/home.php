<!DOCTYPE html>
<?php 
	header( 'Cache-Control: no-store, no-cache, must-revalidate' ); 
	header( 'Cache-Control: post-check=0, pre-check=0', false ); 
	header( 'Pragma: no-cache' );

	session_start();
	require "config.php";
	if ((isset($_POST["reply"]) && !empty($_POST["reply"]) ) && (isset($_POST["id"]) && !empty($_POST["id"]))){
	$reply=$_POST["reply"];
	$qid=$_POST["id"];
    $staff_id=$_SESSION['staff_id'];    
	//$currentUser= $_SESSION['currentUser'];
    $currentUser=$_SESSION["currentUser"];    
	//$creationdate =date();
    $conn=$_SESSION["conn"];
	if (!$conn)
		die("Connection failed: " . mysqli_connect_error());
if(isset($staff_id) ){
	$sql="INSERT INTO replytbl (user,staff_id,qid,answer)"
		  ."VALUES ('',$staff_id,$qid,'$reply')";
    //$confirmReply=""
		 if(mysqli_query($conn,$sql)){
//		 	echo "inserting successful";
		 	unset($_POST);
		 //	echo '$_POST[name]'.$_POST["name"];
		 }
		 else { 
		 	echo "<h3>Error inserting!! ".mysqli_error($conn)."</h3>";
//		 	unset($_POST);
		 }
        $update="update pendingqueriestbl set replied=true where qid='$qid'";
        if(mysqli_query($conn,$update)){
		 //	echo "updating successful";
		 	unset($_POST);
		 //	echo '$_POST[name]'.$_POST["name"];
		 }
		 else { 
		 	echo "<h3>Error updting!! ".mysqli_error($conn)."</h3>";
		 	unset($_POST);
		 }
  //      loadPendingQueries();
   //      loadOptions();  
	 }
    else{
        echo "is seems something wasnt set.<br />";    
        echo "currentUser== $currentUser<br />";
        echo "staff_id== $staff_id<br />";
    }
    
    }

                    function loadPendingQueries(){
                    $conn=$_SESSION["conn"];   
                    $sql="SELECT p.* FROM pendingqueriestbl p inner join helpdesktbl h on p.staff_id = h.staff_id where p.staff_id = h.staff_id AND p.staff_id=".$_SESSION['staff_id']." AND replied=false Order by qid desc";
                        if($result = mysqli_query($conn,$sql)){ 
										if (mysqli_num_rows($result)> 0) {
											echo " <ul class='list-group'>";
										    while($row = mysqli_fetch_assoc($result)) {
										    		echo "<li class='list-group-item'>";
                                                    echo "<h2>".$row["qid"]."#</h2>";
                                                    echo "<span class=''>User:".$row["user"].
                                                        "</span> <br />"."</span><br />Query:".
                                                        $row["query"];
										  		 	echo "	</li>";
										    }
											echo "</ul>";
										} 
                        }
                    }
                function loadOptions(){
                    $conn=$_SESSION["conn"];   
                    $sql="SELECT p.* FROM pendingqueriestbl p inner join helpdesktbl h on p.staff_id = h.staff_id where p.staff_id = h.staff_id AND p.staff_id=".$_SESSION['staff_id']." AND replied=false Order by qid desc";
                        if($result = mysqli_query($conn,$sql)){ 
										if (mysqli_num_rows($result)> 0) {
											echo " <select  name='id' class='form-control col-xs-3' form='reply'>";
										    while($row = mysqli_fetch_assoc($result)) {
                                                    echo "<option value='".$row["qid"]."'>".$row["qid"]."</option>";
										    }
										  echo "	</select>";
										} 
                        }
                    }
	
?>
<html>	
	<head> 
		<meta name="author"  content="Pappi Malope">
		<title>
			
		</title>
		<meta charset="UTF-8" />
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="styles/styles.css">
		<script src="bootstrap/js/jquery-2.1.3.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container-fluid">
			<div class="box">
                <div class="row">
                    <form action="home.php" class="col-md-6 col-md-offset-3" method="post" id="reply">	
                        <input type="text" class="form-control col-md-6"  name="reply" placeholder="Type reply here"/>	
                        <?php loadOptions() ?>
                        <input type="submit" class="form-control" name="submit" class="btn btn-default" />
                    </form>
                </div>
				<div class="ads row col-md-6 col-md-offset-3 col-xs-12">
				<?php	
                    loadPendingQueries();
                ?>
				</div>
			</div>	
		</div>
	</body>
</html>