-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2016 at 09:42 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ssdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladvertisements`
--
CREATE TABLE IF NOT EXISTS `pendingqueriestbl` (
`qid` int(11) PRIMARY KEY AUTO_INCREMENT,
  `replied` boolean NOT NULL  ,
  `staff_id`  int(11) NOT NULL references helpdesktbl(`staff_id`),
  `user` varchar(100) NOT NULL,
  `query` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `helpdesktbl` (
`staff_id` int(11) PRIMARY KEY AUTO_INCREMENT,
  `status` boolean NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `replytbl` (
`reply_id` int(11) PRIMARY KEY AUTO_INCREMENT,
  `user` varchar(100) NOT NULL,
  `staff_id` varchar(100) NOT NULL references helpdesktbl(`staff_id`),
  `answer` text NOT NULL,
   `qid` int(11) NOT NULL references pendingqueries(`qid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbladvertisements`
--


--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladvertisements`
--

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladvertisements`
--
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
