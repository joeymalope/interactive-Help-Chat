$(document).ready(function () {
var helpChat= function () {
     //    var states = {"mailBox" , "LiveChat"};
         var currentState ="";
            
    
        var mailBox=function(){
            alert($('input[name=staff]:checked').val());    
            $('#submit').click(function(){
              //  alert("");
                $.post("updateHelpChat.php",function(data){
                alert(data);    
                $('.chatarea').text(data);
            });
                });
            };
        mailBox();
        };

            $('#submit').click(function(){
              //  alert("");
              //  helpChat(); 
                var name=$('name')
                var staff_id=$('input[name=staff]:checked').val();
                var query= $('#query').val();
            });   
   
});