<?php 
//echo "successfullyy connected";
//var_dump($_POST);
if(isset($_POST["query"]) && isset($_POST["name"])){
    if(trim($_POST["query"])!=="" && trim($_POST["name"])!=="" ){
        require "config.php";    

        $name=$_POST["name"];
        $staff_id=$_POST["staff"];
        $query=$_POST["query"];   
        echo "$name $staff_id $query";    
        //$search="SELECT * FROM users WHERE email='$email' AND password='$password'";
        $insert="INSERT INTO pendingqueriestbl (user,staff_id,query) VALUES ('$name',$staff_id,'$query')";
        if(mysqli_query($conn,$insert))
            echo "successfully inserted<br />";
        else echo "error ".mysqli_error($conn);    


        $retrieve="SELECT * FROM pendingqueries";
        if($result=mysqli_query($conn,$retrieve))
            echo "successful<br />";
        else echo "error ".mysqli_error($conn);    

        echo "<br />num rows ==".mysqli_num_rows($result);
        }
    else 
        echo "atleast u tried<br />";
}
else echo"didnt even go in (thats what she said)<br />";
echo "end";
?>